`has.ngenes.attr` <-
function(obj) !is.null(attr(obj,"ngenes"))

