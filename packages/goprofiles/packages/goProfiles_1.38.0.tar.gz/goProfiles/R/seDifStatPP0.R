`seDifStatPP0` <-
function(pn, p0 = NULL, funcProfP0 = NULL, simplify=T) {
  sqrt(varDifStatPP0(pn, p0, funcProfP0, simplify))
}

