`as.ExpandedGOProfile` <-
function(x, expandedCatNames=NULL) {        
    UseMethod("as.ExpandedGOProfile")
}

