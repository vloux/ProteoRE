`has.element` <-
function(set, element) {
    return(element %in% set)
}

