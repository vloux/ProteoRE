`contractCol` <-
function(pGO, namesVec) {
  names(pGO) <- namesVec
  contractedProfile(pGO)
}

